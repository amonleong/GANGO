
#############################################################################3
# GANGO
##############################################################################

# Toni Monleon. Biost3. 12-2019

#' Function to compute genes, GO, PATHWAYS, KEGG, proteins anotated in Uniprot from taxons
#' @param taxon Taxon selected to map genes and GO
#' @param group Taxon selected to map genes and GO
#' @param callto_old_file = F Call old file to add next results
#' @param Gene_yes = F File from Genes not taxons
#' @param Gene_list  List of genes
#' @param All_fields=F Map of GO, PATWAYS, KEGG (It needs lot of time!!)
#' @return matrix with taxons, groups, genes and gene antologies associate
#' @export
#'
#' @examples
#############################
#' #First example: GENES ANOTATED in Diversity of Fungi in Soil Polluted with Diesel Oil
#' # DATA FROM: https://www.frontiersin.org/articles/10.3389/fmicb.2017.01862/full
#' #Taxons identified in the experiment COMPLETE
#' taxons_dieseloil_control<- c("Aspergillus fumigatus", "Candida lipolytica", "Fusarium solani",  "Fusarium proliferatum", "Microsporum equinum", "Penicillium discolor", "Rhizopus oryzae",
#'                             "Aspergillus fumigatus", "Candida lipolytica", "Fusarium solani", "Fusarium proliferatum", "Microsporum equinum", "Penicillium chrysogenum", "Penicillium digitatum", "Penicillium discolor", "Penicillium discolor","Penicillium fumiculosum",  "Penicillium expansum", "Rhizopus oryzae")
#'
#' #Experimental groups (C=ontrol, DO=diesel oil)
#' group_dieseloil_control<- c("DO","DO","DO","DO","DO","DO","DO",
#'                            "C","C","C","C","C","C","C","C","C","C","C","C")
#' #Taxons identified in the experiment SIMPLIFICATION
#' taxons_dieseloil_control1<- c("Aspergillus fumigatus", "Candida lipolytica",
#'                              "Penicillium expansum", "Rhizopus oryzae")
#'
#' #Experimental groups (C=ontrol, DO=diesel oil)
#' group_dieseloil_control1<- c("DO","DO",
#'                            "C","C")
#' #Use GANGO to search anotated GO, PATWAY, KEGG, PROTEINS(Map GO from taxons) in UNIPROT
#' #Save results in:
#' setwd("C:/Users/Toni/Downloads")
#' #Map GO from UNIPROT using GANGO (Maybe a lot of time!!!!)
#' GO.detaxon<-GANGO(taxon=taxons_dieseloil_control1, group=group_dieseloil_control1,callto_old_file = F,All_fields = F,Gene_yes = F)
#' # Map GO from UNIPROT using GANGO (Maybe a lot of time!!!!)
#' #GO.detaxon1<-GANGO(taxon=taxons_dieseloil_control1, group=group_dieseloil_control1,callto_old_file = F,All_fields = T,Gene_yes = F)
#' #GANGO results:
#' cross_table<-GO.detaxon[[1]] #Cross table of GO and groups
#' res3<-GO.detaxon[[3]]
#'
#' #Results of differentially proportions using dif.propOTU.between.groups() of library(BDSbiost3)
#' library(BDSbiost3) #Download at https://github.com/amonleong/BDSbiost3
#' dif.propOTU.between.groups(matriu = cross_table, vector.labels=colnames(cross_table), alfa=0.05, lim.padj = 0.00001, lim.log2FoldChange =9)
#'
#' #coincidence analysis between groups using library(BDSbiost3)
#' coincidence.analysis(cross_table)






#' @references
#' Toni Monleón-Getino, Andreu Paytuví, Walter Sanseverino, Javier Méndez. 2020.G.A.N.G.O.A new bioinformatic tool to interpret metagenomic / metatranscriptomics results based on the geometry of the spectral clustering network and its differentially gene ontologies
#' ECFG15 - 15TH EUROPEAN CONFERENCE ON FUNGAL GENETICS, biology, host pathogen interaction & evolutionary ecology.
#' Proceedings. February 2020. Roma (Italy).




GANGO<- function(taxon, group, callto_old_file = F,  Gene_yes = F, Gene_list, All_fields=F){

  #PAQUETE DE ANALISIS VISUAL DE GO: https://cran.r-project.org/web/packages/GOplot/vignettes/GOplot_vignette.html

  #grafico muy chulo sobre GO: https://www.researchgate.net/publication/311853230_Brain_transcriptomes_of_harbor_seals_demonstrate_gene_expression_patterns_of_animals_undergoing_a_metabolic_disease_and_a_viral_infection/figures?lo=1

  #this function is to obtain GO genes and taxons using UNIPROT(TAXON) of the different experimental-groups
  #INPUT: TAXON - OUTPUT: GENES, GO
  library(rentrez)
  library(UniProt.ws)

  #se crea un dataframe de inicio nuevo para recoger datos de la GO
  if(callto_old_file == F){

    select_results_t<- data.frame("UNIPROTKB"=c(NA), "GO"=c(NA), "GO-ID"=c(NA),
                                  "ID_ROW"=c(NA), "TAXON"=c(NA), "GROUP"=c(NA)) #create a na data frame

    if(All_fields==T){
      select_results_t<- data.frame("UNIPROTKB"=c(NA), "GO"=c(NA), "GO-ID"=c(NA),
                                    "KEGG"=c(NA), "KO"=c(NA), "DRUGBANK"=c(NA),"PROTEIN-NAMES"=c(NA),"PATHWAY"=c(NA),"PDB"=c(NA),
                                    "PHARMGKB"=c(NA),"ENSEMBL_GENOMES PROTEIN"=c(NA), "ENSEMBL_PROTEIN"=c(NA),
                                    "ID_ROW"=c(NA), "TAXON"=c(NA), "GROUP"=c(NA)) #create a na data frame

    }

  }
  #NO se crea un dataframe de inicio nuevo para recoger datos de la GO. SE LLAMA A FICHERO ANTERIOR.
  #DIRECTORIO DE TRABAJO
  if(callto_old_file == T){
    load("data_select_results_t.Rda")
  }



  for(i in 1:length(taxon)){
    #i<-1
    #buscar el TAXON------------------!!!!!!!!!!!!!!!!!!!!
    #se busca mediante un patron de la especie, así llegan todas las cepas
    taxon_all<-availableUniprotSpecies(taxon, n=Inf)
    taxon_all_id<- c(taxon_all$`taxon ID`)
    taxon_all_name<- c(taxon_all$`Species name`)
    print(paste("ID-row=", i, ", Taxon ID= ", taxon_all_id,", species= ", taxon_all_name, sep=""))


    #no se ha encontrado ninguna coincidencia con el taxon indicado
    if(length(taxon_all_id)==0){
      #organismo - taxon----------------------------------------------------------------------------
      taxon_search = entrez_search(db="taxonomy", term=taxon[i])
      id.taxon <- taxon_search$ids #"1689" "Bifidobacterium dentium"
      id.taxon
      print(paste("ID-row=", i, ", " , taxon[i], ", Taxon ID= ", id.taxon,sep=""))
      #asignar
      taxon_all_id<- as.numeric(id.taxon)
      taxon_all_name<- taxon[i]
    }



    #si todo es correcto-> se ha identificado el taxon
    if(is.null(unlist(taxon_all_id))!=T ){

      #######################################################################
      # mapar los genes de un taxon en UNIPROTKB
      #######################################################################


      #nueva libreria de uniprot
      #library(UniProt.ws)
      #https://bioconductor.org/packages/devel/bioc/manuals/UniProt.ws/man/UniProt.ws.pdf
      #if (!requireNamespace("BiocManager", quietly = TRUE))
      #  install.packages("BiocManager")

      #BiocManager::install("UniProt.ws")

      #up <- UniProt.ws(taxId = 9606) #SEE AT: https://github.com/Bioconductor/UniProt.ws/issues/3
      #up
      #res <- select(up, keys = "A2A2A0", columns = c("GO","GO-ID"), keytype = "UNIPROTKB")
      #rm(up)
      #id.taxon <- 307796
      #up <- UniProt.ws(taxId=as.numeric(id.taxon)) #taxon de la lista
      #length(up@taxIdUniprots)

      for(k in 1:length(taxon_all_id) ){ #para toda una lista de taxones, de la especie que se solicita (cepas)


        #k<-1
        up <- UniProt.ws(taxId=taxon_all_id[k]) #taxon de la lista
        length(up@taxIdUniprots)



        print(paste("number of genes Uniprot= ", length(up@taxIdUniprots),sep=""))
        if(length(up@taxIdUniprots)>0){ #genes anotados en Unirpot

          #rm(egs)
          ## list the keys that can be retreived -puedo mirar en ensebl, uniprotkb, entrez, etc
          #keytypes(up)
          ## list the columns that can be retreived
          #columns(up) #campos de informacion
          #busco genes ANOTADOS EN UNIPROTKB QUE ESTEN ANOTADOS PARA EL TAXON
          #pueden ser de una lista de genes o todos los del taxon
          if(Gene_yes==T){
            #egs<-Gene_list
            #cuando se trata de una lista de genes de un solo taxon
            #proceso:
            #length(egs) #numero de genes anotados en uniprotkb
            #long<-length(egs)
            #data.frame of all: taxon, gene_list and groups
            tog<- data.frame(Gene_list, group)
            for(i in levels(as.factor(tog$group))){
              #i<-"G_fcNEG"
              #seleccion para cada nivel de grupo
              tog1 <- tog[ which(tog$group==i), ]


              #CAMPOS RECUPERADOS EN UNIPROTKB: egs[1]
              #select_results<-select(up, keys=tog1$Gene_list, columns=c("GO","GO-ID", "GENES", "UNIPROTKB"),  keytype="UNIPROTKB")
              #colnames(select_results)<-c("UNIPROTKB", "GO", "GO.ID",  "GENES" )
              #ALTERNATIVAMENTE:

              if(All_fields==T){
                select_results<-select(up, keys=tog1$Gene_list, columns=c("GO","GO-ID",
                                                                          "KEGG", "KO", "DRUGBANK","PROTEIN-NAMES","PATHWAY","PDB","PHARMGKB","ENSEMBL_GENOMES PROTEIN", "ENSEMBL_PROTEIN"),
                                       keytype="UNIPROTKB")

              }
              if(All_fields==F){
                select_results<-select(up, keys=tog1$Gene_list, columns=c("GO","GO-ID"),
                                       keytype="UNIPROTKB")

              }

              #variables indicadoras
              select_results$ID_ROW<-1
              select_results$TAXON<-taxon_all_name[k] #antes era:taxon
              select_results$GROUP<-i
              #class(egs)
              #names(select_results)
              #select_results<-select(up, keys=Gene_list[2], columns=c("GO","GO-ID", "GENES", "UNIPROTKB", "KEGG", "KO"),  keytype="UNIPROTKB")

              #COLUMN LABELS
              if(All_fields==F){
                colnames(select_results)<-c("UNIPROTKB", "GO", "GO.ID","ID_ROW",    "TAXON",     "GROUP")
              }
              if(All_fields==T){
                colnames(select_results)<-c("UNIPROTKB", "GO", "GO.ID",
                                            "KEGG", "KO", "DRUGBANK","PROTEIN.NAMES","PATHWAY","PDB","PHARMGKB","ENSEMBL_GENOMES.PROTEIN", "ENSEMBL_PROTEIN",
                                            "ID_ROW",    "TAXON",     "GROUP")
              }

              #select_results_t<- data.frame("UNIPROTKB"=c(NA), "GO"=c(NA), "GO-ID"=c(NA), "GENES"=c(NA), "ID_ROW"=c(NA), "TAXON"=c(NA), "GROUP"=c(NA)) #create a na data frame

              #resultados
              #names(select_results)
              select_results_t<- rbind(select_results_t, select_results)

            }

          }

          if(Gene_yes==F){
            #cuando se trata de una lista de diferentes taxones y todos los genes anotados alli
            if(interactive()){
              egs = keys(up, "UNIPROTKB")
              #save(egs,file="egs.Rda")
              #write.csv(egs, file = "egs.csv")
            }

            #proceso:
            length(egs) #numero de genes anotados en uniprotkb
            long<-length(egs)

            #if(long>10){long<-10} #coger los 10 primeros genes de momento
            #hay mas de un registro anotado
            #CAMPOS RECUPERADOS EN UNIPROTKB: egs[1] -------------------
            #select_results<-select(up, keys=egs[1:long], columns=c("GO","GO-ID", "GENES", "UNIPROTKB"),  keytype="UNIPROTKB")
            #colnames(select_results)<-c("UNIPROTKB", "GO", "GO.ID",  "GENES" )
            #ALTERNATIVA 30-12-2019
            if(All_fields==T){
              select_results<-select(up, keys=egs[1:long], columns=c("GO","GO-ID",
                                                                     "KEGG", "KO", "DRUGBANK","PROTEIN-NAMES","PATHWAY","PDB","PHARMGKB","ENSEMBL_GENOMES PROTEIN", "ENSEMBL_PROTEIN"),
                                     keytype="UNIPROTKB")
              colnames(select_results)<-c("UNIPROTKB", "GO", "GO.ID",
                                          "KEGG", "KO", "DRUGBANK","PROTEIN.NAMES","PATHWAY","PDB","PHARMGKB","ENSEMBL_GENOMES.PROTEIN", "ENSEMBL_PROTEIN")
            }

            if(All_fields==F){
              select_results<-select(up, keys=egs[1:long], columns=c("GO","GO-ID"),
                                     keytype="UNIPROTKB")
              colnames(select_results)<-c("UNIPROTKB", "GO", "GO.ID")

            }

            select_results$ID_ROW<-i
            select_results$TAXON<- taxon_all_name[k] #antes era taxon[i]
            select_results$GROUP<-group[i]
            #class(egs)
            #names(select_results)
            #alternativa para mas campos (no va bien, alternativa)
            #select_results1<-select(up, keys=egs[1:long], columns=c("GO","GO-ID", "GENES", "UNIPROTKB",
            #                                                        "DRUGBANK",
            #                                                        "PROTEIN-NAMES",
            #                                                        "PATHWAY",
            #                                                        "KEGG",
            #                                                        "PDB",
            #                                                        "PHARMGKB",
            #                                                        "KO",
            #                                                        "ENSEMBL_GENOMES PROTEIN",
            #                                                        "ENSEMBL_PROTEIN"),  keytype="UNIPROTKB")

            #select_results1$ID_ROW<-i
            #select_results1$TAXON<-taxon[i]
            #select_resultsv$GROUP<-group[i]

            #select_results_t<- data.frame("UNIPROTKB"=c(NA), "GO"=c(NA), "GO-ID"=c(NA), "GENES"=c(NA), "ID_ROW"=c(NA), "TAXON"=c(NA), "GROUP"=c(NA)) #create a na data frame

            #resultados
            #names(select_results)
            select_results_t<- rbind(select_results_t, select_results)

          }


        }

        #save session de vez en cuendo
        save(select_results_t,file="data_select_results_t.Rda")
      }
    }






  }




  #hacer una seleccion de los registros
  select_results_t_complete <- select_results_t[complete.cases(select_results_t[ , 3]),]
  #select_results_t_complete1<- lapply(select_results_t_complete, gsub, pattern='.', replacement='')

  #split de solo las GO
  s <- strsplit(select_results_t_complete$GO.ID, split = ";")
  GO_split<-data.frame(GO_types_combinations = rep(select_results_t_complete$GO.ID, sapply(s, length)),
                       GO_types = unlist(s),
                       genes = rep(select_results_t_complete$UNIPROTKB, sapply(s, length)),
                       taxon = rep(select_results_t_complete$TAXON, sapply(s, length)),
                       group = rep(select_results_t_complete$GROUP, sapply(s, length))
  )
  #ejemplo en https://stackoverflow.com/questions/15347282/split-delimited-strings-in-a-column-and-insert-as-new-rows

  #print(table(GO_split$GO_types))



  #cross classication counts for GO_types, group
  cross_table<- as.data.frame.matrix(table(GO_split$GO_types, GO_split$group))
  #dim(cross_table) #4865    7
  #summary(cross_table)
  #colnames(cross_table)<-c("G1","G2","G3")


  #ANALISIS DE COINCIDENCIAS------------------------------------------------------
  #head(cross_table)
  #library(BDSbiost3)
  #coincidence.analysis(matriu1=cross_table)
  #class(cross_table)

  all_cases<-select_results_t


  #select_results DATAFRAME CON LOS RESULTADOS
  return(list(cross_table, GO_split, select_results_t_complete, all_cases))

}






###################################################################################################
# enrichment.test.TM: FUNCTION TO DO A ENRICHMENT ANALYSIS FROM A GO FREQUENCIES (GROUPS)
###################################################################################################
enrichment.test.TM <- function(cross_table){

  ########## enrichment analysis casero ###########################################################
  ###########################TARDA 30 MINUTOS ------- !!!! ------------------------------------

  #todas las colunas tienen que tener resultados de GO sino eliminar
  cross_table1<- cross_table[colSums(cross_table) > 1]
  if(ncol(cross_table1)< ncol(cross_table)){
    print("Some group has not a significant number of GO, so it will be removed")
  }


  #analisis de enriquecimiento -------------------------------------------------------


  #combinaciones choose(n=ncol(cross_table),k=2
  library(EnvStats)
  #vector.noms.grups<- array("", dim=c(comb) )
  p.values.GO.enrichment<-matrix(NA, nrow = nrow(cross_table1), ncol = ncol(cross_table1))
  padj.values.GO<-matrix(NA, nrow = nrow(cross_table1), ncol = ncol(cross_table1))
  dif.prop.GO.enrichment<-matrix(NA, nrow = nrow(cross_table1), ncol = ncol(cross_table1))

  rownames(p.values.GO.enrichment)<-rownames(cross_table1)
  for (i in 1: nrow(cross_table1)){ #para cada GO
    for (j in 1:ncol(cross_table1)) { #SELECCIONAR GRUPO1

      #i<-1
      #j<-1 ncol(cross_table1)
      print(paste("GO=",i))
      print(paste("GROUP=",j))
      #Suma total:----------------------------------------------------------------------
      total<-sum(cross_table1[i,])
      positives<-cross_table1[i,j]
      negatives<-total-positives
      dat1 <- c(rep(1,positives),rep(0,negatives))
      dat2 <- c(rep(1,negatives),rep(0,positives))
      set.seed(23)
      #library(EnvStats)
      #test estadistico exacto de Fisher
      if (sum(dat1)>0 & sum(dat2) >0){
        test.list <- twoSamplePermutationTestProportion(
          dat1, dat2, alternative = "two.sided")
        #guardar p.valor
        p.values.GO.enrichment[i,j]<-test.list$p.value
        dif.prop.GO.enrichment[i,j]<- (sum(dat1) - sum(dat2)) /total  #en este hace el valor absoluto --> test.list$statistic
      }

    }
  }

  #i<-1 p.values adjusted using fdr
  for(i in 1:ncol(p.values.GO.enrichment)){
    padj.values.GO[,i]=p.adjust(as.matrix(p.values.GO.enrichment[,i]), "fdr")
  }
  matriu.GO.enrichment.results<- data.frame(cbind(p.values.GO.enrichment, padj.values.GO, dif.prop.GO.enrichment))
  nc<-ncol(cross_table1)
  names(matriu.GO.enrichment.results)[1:nc]<- c(paste(colnames(cross_table1),".pval",sep=""))
  names(matriu.GO.enrichment.results)[(nc+1):(2*nc)]<- paste(colnames(cross_table1),".p.adj",sep="")
  names(matriu.GO.enrichment.results)[(2*nc+1):(3*nc)]<- paste(colnames(cross_table1),".dif.prop",sep="")
  #summary(matriu.GO.enrichment.results)
  #grafico de los pvalores ajustados y los GO


  #hacer graficos y calculos del fold change---------------------------------------------------------------------------------------
  #calcular los log2foldchange para todos los grupos-------------------------------------------------------
  #representar plot volcano para todos los grupos
  #graficos volcano plots--------------------------------------
  aaa.b<-matriu.GO.enrichment.results
  names(aaa.b)[(nc+1):(2*nc)]<- paste(colnames(cross_table1),"_l10.pa",sep="")
  names(aaa.b)[(2*nc+1):(3*nc)]<- paste(colnames(cross_table1),"_FCH",sep="")
  summary(aaa.b)
  #dejar solo los que toda la fila no sea NA
  aaa.b<-aaa.b[apply(aaa.b,1,function(x)any(!is.na(x))),]

  #calcular el fold change y log(p.value)
  for(k in 1:ncol(cross_table1)){
    #k<-1
    #matriu.GO.enrichment.results$log2FoldChange<-NA
    for(i in 1:dim(aaa.b)[1]){
      #i<-9
      #  if(is.na(matriu.GO.enrichment.results[i,2*nc+k])==F){
      #    if(matriu.GO.enrichment.results[i,2*nc+k] > 0){ matriu.GO.enrichment.results$log2FoldChange[i] <- -log2(matriu.GO.enrichment.results[i,2*nc+k])}
      #    if(matriu.GO.enrichment.results[i,2*nc+k] <= 0){ matriu.GO.enrichment.results$log2FoldChange[i] <- log2(abs(matriu.GO.enrichment.results[i,2*nc+k]))}
      #  }
      #
      #aaa.b---------------------------------------------------
      #trasformar a foldchange
      if(is.na(aaa.b[i,2*nc+k])==F){
        if(aaa.b[i,2*nc+k] > 1e-10){ aaa.b[i,2*nc+k] <- -log2(aaa.b[i,2*nc+k])}
        if(aaa.b[i,2*nc+k] <= 1e-10){ aaa.b[i,2*nc+k] <- log2(abs(aaa.b[i,2*nc+k]))}
      }
      if( is.na(aaa.b[i,2*nc+k]) ==T){ aaa.b[i,2*nc+k] <- log2(1e-30)}
      #trasnformar a log10(pvalue)
      aaa.b[i,nc+k] <- -log10(aaa.b[i,nc+k])
      if( is.finite(aaa.b[i,nc+k])==F){aaa.b[i,nc+k]<-300}
    }
  }
  #summary(aaa.b)



  #plot volcano ??????????????????
  #matriu.GO.enrichment.results.aux<-matriu.GO.enrichment.results
  #  matriu.GO.enrichment.results.aux<-subset(matriu.GO.enrichment.results.aux, matriu.GO.enrichment.results.aux[,nc+k] <lim.padj & abs(log2FoldChange)<lim.log2FoldChange)
  #Hay mas de 1
  #if(dim(matriu.GO.enrichment.results.aux)[1]>0){
  #  rownames(matriu.GO.enrichment.results.aux)<-1:dim(matriu.GO.enrichment.results.aux)[1]
  #}
  #  res <- try(plot(matriu.GO.enrichment.results.aux$log2FoldChange, -log10(matriu.GO.enrichment.results.aux[,nc+k]),xlab = "log2FoldChange", ylab = "-log10(p.valadj)" ),silent = TRUE)
  #grabar
  #  if(class(res) != "try-error"){
  #    plot(matriu.GO.enrichment.results.aux$log2FoldChange, -log10(matriu.GO.enrichment.results.aux[,nc+k]),xlab = "log2FoldChange", ylab = "-log10(p.valadj)",col="red",cex=0.5 )
  #    title(main = paste(names(matriu.GO.enrichment.results.aux[nc+k]), "-VOLCANO PLOT"), sub = "GO")
  #    text(x =matriu.GO.enrichment.results.aux$log2FoldChange ,y=-log10(matriu.GO.enrichment.results.aux[,nc+k]),labels = rownames(matriu.GO.enrichment.results.aux),cex=0.5,pos = 4)
  #   abline(v=0,lty = 3)
  #  }

  #}
  #solo foldchange y log(pvalue)
  #summary(aaa.b)
  aaa.b1 <- aaa.b #aaa.b[,colSums(is.na(aaa.b))<(nrow(aaa.b))]
  ngroups <- ncol(aaa.b1)/3
  #seleccionar pvalue adjusted y cfold
  #aaa.b1<-aaa.bb1[,-c(1:ngroups)]

  #cambiar los infinitos por valor 300, son pvalores log10 que salen infinito
  for(i in 1:dim(aaa.b1)[1]){
    for(k in 1:ngroups){
      #k<-1
      #i<-7
      if( is.null(aaa.b1[i,(2*ngroups+k)])==F){
        if( is.finite(aaa.b1[i,(2*ngroups+k)])==F){aaa.b1[i,(2*ngroups+k)]<-300}
      }

    }

  }
  #summary(aaa.b1)
  #library(IDPmisc)
  #aaa.b1.sinna<-NaRV.omit(aaa.b1) #quitar infinitos, menos infinitos y NA
  #aaa.b1.sinna<-na.omit(aaa.b1)


  #PCA DE TODO CON TODOS LOS GO
  res.prcomp<-prcomp(aaa.b1[,(ngroups+1):dim(aaa.b1)[2]])
  plot(res.prcomp)
  print(summary(res.prcomp))
  biplot(res.prcomp)
  title(main = "", sub = "ALL GO-PCA BIPLOT")


  #aaa<-subset(matriu.GO.enrichment.results, matriu.GO.enrichment.results[,nc+k] <lim.padj & abs(log2FoldChange)<lim.log2FoldChange)
  #text(aaa$log2FoldChange, -log10(aaa[,nc+k]), labels=rownames(aaa), cex= 0.3, pos=3, col="red")

  #graficos avanzados-tardan mucho-----------------
  #if(volcano_gr==T){

  # representacion de p.valores en un volcano plot (de momento no)
  #  library(ggrepel)
  #  library(ggplot2)
  #  p <- ggplot(data = matriu.GO.enrichment.results, aes(x=log2FoldChange, y=-log10(matriu.GO.enrichment.results[,nc+1]), label = rownames(matriu.GO.enrichment.results))) +
  #    geom_point(color = "red", alpha=1, size=2)
  #  lab.v<- "grupos a comparar"
  #  p2 <- p + geom_text_repel() + labs(title = lab.v) +
  #    labs(x = "log2(Fold change)", y="-log10(p adjusted)") + labs(colour = "log2FoldChange")

  #volcano plot de solo los filtrados
  #lim.padj<- 0.001
  #lim.log2FoldChange<-3
  #  aaa<-subset(matriu.GO.enrichment.results, matriu.GO.enrichment.results[,nc+1] <lim.padj & abs(log2FoldChange)<lim.log2FoldChange)
  #  p1 <- ggplot(data = aaa, aes(x=log2FoldChange, y=-log10(aaa[,nc+1]), label = rownames(aaa))) +
  #    geom_point(color = "red", alpha=1, size=2)
  #  lab.v<- "grupos a comparar"
  #  p2 <- p + geom_text_repel() + labs(title = lab.v) +
  #    labs(x = "log2(Fold change)", y="-log10(p adjusted)") + labs(colour = "log2FoldChange")
  #  gridExtra::grid.arrange(p2, ncol = 1)

  #representacion de los 2 graficos
  #  gridExtra::grid.arrange(p2, p3, ncol = 2)
  #}


  return(list(matriu.GO.enrichment.results, aaa.b1))

}






###########################################################################################################
# MAP.GO.LIST = FUNCTION TO MAP THE GENE ONTOLOGIES - pone GO a un dataframe
###########################################################################################################
map.GO.list.labels<- function(aaa.1){

  #cuando ya tengo los terminos enriquecidos quiero saber loq ue son para ello voy a la base de datos
  #AQUI SE PUEDE BUSCAR LA JERARQUIA: http://supfam.org/SUPERFAMILY/cgi-bin/go.cgihttp://supfam.org/SUPERFAMILY/cgi-bin/go.cgi
  #if (!requireNamespace("BiocManager", quietly = TRUE))
  #  install.packages("BiocManager")
  #BiocManager::install("GO.db")
  #ncols.aaa1<- ncol(aaa.1) #columnas originales

  #numero de grupos
  #ngroups<-(ncol(aaa.1)/2)
  #pone los nombres, tipos a los GO --------------------------
  library(GO.db)
  GO.list<-list(gsub(" ", "", rownames(aaa.1)))
  #i<-5
  #GO.list[[1]][i]
  #GO.list.GOID<- GOID(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Term<- Term(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Synonym<- Synonym(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Secondary<- Secondary(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Definition<- Definition(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Ontology<- Ontology(GOTERM[[GO.list[[1]][i]]])

  #lista de todos los GO sin espacios
  GO.list<-list(gsub(" ", "", rownames(aaa.1)))
  aaa.1$GO.subtype<- NA
  for(i in 1:dim(aaa.1)[1]){
    #guardar en grupo

    res <- try(Ontology(GOTERM[[GO.list[[1]][i]]]),silent = TRUE)
    #grabar
    if(class(res) != "try-error"){
      aaa.1$GO.subtype[i] <- Ontology(GOTERM[[GO.list[[1]][i]]])
      aaa.1$GO.Term[i] <- Term(GOTERM[[GO.list[[1]][i]]])
    }
    if(class(res) == "try-error"){
      aaa.1$GO.subtype[i] <- NA
    }
  }


  return(aaa.1)
}










###########################################################################################################
# MAP.GO.LIST = FUNCTION TO MAP THE GENE ONTOLOGIES AND TO DO A VOLCANO PLOTS AND PCA OF GO-SUBTYPES
###########################################################################################################
map.GO.list<- function(aaa.1, volcano_gr=F, lim.padj=1e-50,  lim.log2FoldChange=2){

  #cuando ya tengo los terminos enriquecidos quiero saber loq ue son para ello voy a la base de datos
  #AQUI SE PUEDE BUSCAR LA JERARQUIA: http://supfam.org/SUPERFAMILY/cgi-bin/go.cgihttp://supfam.org/SUPERFAMILY/cgi-bin/go.cgi
  #if (!requireNamespace("BiocManager", quietly = TRUE))
  #  install.packages("BiocManager")
  #BiocManager::install("GO.db")
  #ncols.aaa1<- ncol(aaa.1) #columnas originales

  #numero de grupos
  ngroups<-(ncol(aaa.1)/2)
  #pone los nombres, tipos a los GO --------------------------
  library(GO.db)
  GO.list<-list(gsub(" ", "", rownames(aaa.1)))
  #i<-5
  #GO.list[[1]][i]
  #GO.list.GOID<- GOID(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Term<- Term(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Synonym<- Synonym(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Secondary<- Secondary(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Definition<- Definition(GOTERM[[GO.list[[1]][i]]])
  #GO.list.Ontology<- Ontology(GOTERM[[GO.list[[1]][i]]])

  #lista de todos los GO sin espacios
  GO.list<-list(gsub(" ", "", rownames(aaa.1)))
  aaa.1$GO.subtype<- NA
  for(i in 1:dim(aaa.1)[1]){
    #guardar en grupo

    res <- try(Ontology(GOTERM[[GO.list[[1]][i]]]),silent = TRUE)
    #grabar
    if(class(res) != "try-error"){
      aaa.1$GO.subtype[i] <- Ontology(GOTERM[[GO.list[[1]][i]]])
      aaa.1$GO.Term[i] <- Term(GOTERM[[GO.list[[1]][i]]])
    }
    if(class(res) == "try-error"){
      aaa.1$GO.subtype[i] <- NA
    }
  }
  #por ejemplo hacer un PCA del data frame AAA con todos los grupos PARA PVAL ADJUSTED, FOLDCHANGE, Y ETIQUETA DE LA ONTOLOGIA
  #PARA LAS SUB-GO -> BP, MF, CC

  #seleccion de inflamacion --- no sale nada
  #cross_table[c(" GO:0006954"," GO:0002526"," GO:0033554", " GO:0070458", " GO:0002217",
  #               " GO:0002543",
  #               " GO:0042829", " GO:0002541"," GO:0002542", " GO:0002438", " GO:0002524",
  #               " GO:0052874"),] #el ultimo es un blanco

  #HACER UN PCA PARA CADA SUBTIPO   ----- BP, MF,--------------------
  #---------------------------------------------------
  aaa.2<-subset(aaa.1, aaa.1$GO.subtype=="BP")
  #si hay mas de 1
  if(dim(aaa.2)[1]>1){
    res.prcomp<-prcomp(aaa.2[,1:(ngroups*2)], scale = T)
    plot(res.prcomp)
    summary(res.prcomp)
    biplot(res.prcomp)
    title(main = "", sub = "GO_BP-PCA BIPLOT")
  }


  #---------------------------------------------------
  aaa.2<-subset(aaa.1, aaa.1$GO.subtype=="MF")
  if(dim(aaa.2)[1]>1){
    res.prcomp<-prcomp(aaa.2[,1:(ngroups*2)], scale = T)
    plot(res.prcomp)
    summary(res.prcomp)
    biplot(res.prcomp)
    title(main = "", sub = "GO_MF-PCA BIPLOT")
  }

  #---------------------------------------------------
  aaa.2<-subset(aaa.1, aaa.1$GO.subtype=="CC")
  if(dim(aaa.2)[1]>1){
    res.prcomp<-prcomp(aaa.2[,1:(ngroups*2)], scale = T)
    plot(res.prcomp)
    summary(res.prcomp)
    biplot(res.prcomp)
    title(main = "", sub = "GO_CC-PCA BIPLOT")
  }


  ################# volcano plots de todos por GO para cada grupo presente
  if(volcano_gr==T){

    for(k in 1:ngroups){
      aaa.11<-subset(aaa.1, aaa.1[,k] > -log10(lim.padj) & abs(aaa.1[,(ngroups+k)])<lim.log2FoldChange)
      #k<-1
      #plot volcano
      plot(aaa.11[,(ngroups+k)],aaa.11[,k],  xlab = "log2FoldChange", ylab = "-log10(p.valadj)",
           col=as.numeric(as.factor(aaa.11$GO.subtype))+1,cex=1.25,pch=as.numeric(as.factor(aaa.11$GO.subtype)) )
      legend("topright", legend=levels(as.factor(aaa.11$GO.subtype)),
             col=2:4,
             pch=1:3, cex=0.8)
      title(main = paste(colnames(aaa.11[k]), "-VOLCANO PLOT"), sub = "GO")
      text(x =aaa.11[,(ngroups+k)] ,y=aaa.11[,k],labels = rownames(aaa.11),cex=0.5,pos = 4)
      abline(v=0,lty = 3)
    }


  }

  return(aaa.1)
}




#####################################################################


#topGO
#HERRAMIENTA  http://bioinformatics.sdstate.edu/go/


##########################################
#old no utilizar o restos de pruebas
###########################################

########################################################################################################
#nombres de los genes-----------------------------------------------------------------------------
#######################################################################################################
#ver link en: https://cran.r-project.org/web/packages/rentrez/vignettes/rentrez_tutorial.html
#all_the_links <- entrez_link(dbfrom='taxonomy', id=id.taxon, db='all')
#genes.find<-all_the_links$links$taxonomy_gene #llarg de temps !!!!!!!!!!!!!
#genes.find #colecciond de genes id
#all_the_links$links$taxonomy_genome2
#taxonomy_unigene_exp
#taxonomy_unigene_exp
#taxonomy_unigene_exp
#debo convertir los genes a nombre-----------------------------------
#if (!requireNamespace("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")
#BiocManager::install("ViSEAGO")
#library(ViSEAGO)
#source("http://bioconductor.org/biocLite.R")
#biocLite("mygene")
#BiocManager::install("mygene")


#gene_search <- entrez_search(db = "gene",  term = paste("(",taxon,"[Organism])",sep = "") )
#genes detectados
#gene_search$ids
#informacion de los genes: nombre, descripción, etc
#multi_summs <- entrez_summary(db="gene", id=gene_search$ids)
#extract_from_esummary(multi_summs, "name")
#extract_from_esummary(multi_summs, "description")
#mas informacion en https://cran.r-project.org/web/packages/rentrez/vignettes/rentrez_tutorial.html
#gene_search_name<-extract_from_esummary(multi_summs, "name") #nombre genes



##############################################
# pasar los genes a uniprot
##############################################
#xli_1<- c(gene_search_name[i])
#BiocManager::install("org.Hs.eg.db")
#library(org.Hs.eg.db)
## Bimap interface:
#x <- org.Hs.egUNIPROT
# Get the entrez gene IDs that are mapped to a Uniprot ID
#mapped_genes <- mappedkeys(x)
# Convert to a list
#xx <- as.list(x[mapped_genes])
#if(length(xx) > 0) {
#  # Get the Uniprot gene IDs for the first five genes
#  xx[1:5]
#  # Get the first one
#  xx[[1]]
#}


#######################################################################################################
#buscar la GO DE LOS GENES DETECTADOS-------NO VA MUY BIEN---------------------------------------------------------------
#######################################################################################################
#library(mygene)

#para cada gen repetir-------------------------------------------------------------------------
#1. Create at list of your gene symbols or entrez gene ids or whatever (various inputs are acceptable as long as they're properly scoped):
#i<-17

#convierte id de genes en sus nombres, pero yo ya los tengo
#gene <- getGene("31606477", fields="all")
#gene[[1]]$symbol
#length(gene)

#xli <- c('BRCA1',  'BRCA2',   'SOX2',  'MYC')
#xli_1<- c(gene[[1]]$symbol)
#xli_1<- c(gene_search_name[i])
#xli_1<-"cas2"
#2. Run the search for the items in your list (in this case, scoping to gene symbols, returning entrezgene id's and gene ontology and restricting to human genes) and display your search results:

#res <- queryMany(xli, scopes='symbol', fields=c('entrezgene', 'go'), species='human')
#res_1 <- queryMany(xli_1, scopes='symbol', fields=c('go'), species='all')
#unlist(res_1)
#str(res_1)

#Results:
#3. Display records of interest (in this case the cellular gene ontology terms for the 1st record, but you can also get the biological process go's and molecular function go's):

#res_1[, 'go.CC'][[1]] #go.BP        go.CC        go.MF
#res_1[, 'go.BP'][[1]]
#res_1[, 'go.MF'][[1]]
#ViSEAGO








# ver en:
#https://www.biostars.org/p/172085/

#up <- UniProt.ws(taxId=1689)
#select(up, keys=c("O76064"), columns=c("INTERPRO"),  keytype="UNIPROTKB")



####################andreu gango########################################################3
#if (!requireNamespace("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")

#BiocManager::install("GO.db")

#library(treemap)
#library(GO.db)
#library(reshape)
#library(ggplot2)

#xx <- as.list(GOBPPARENTS)

#doAnalysis <- function(ff) {
#  m <- read.table(ff,sep="\t", header=F,stringsAsFactors=F)
#  colnames(m) <- c("GO_ID","Query_Total", "Query_Item","BG_Total","BG_Item","GO_Category","GO_Description","Genes")
#  m$p_value <- 1-phyper(m$Query_Item,m$Query_Total,(m$BG_Total-m$Query_Total),m$BG_Item)
#  m$FDR <- p.adjust(m$p_value, "fdr")
#  m$E_Score <- (m$Query_Item/m$Query_Total)/(m$BG_Item/m$BG_Total)
#  m <- subset(m, select=c(1,6,7,2,3,4,5,9,10,11,8))
#  m <- m[order(m$FDR),]
#  m <- subset(m, FDR<=0.05)
#  return(m)
#}

#plotTreeMap <- function(t, stuff) {
#  n_genes_with_go <- 1
#since we have a lot of enriched GO terms, we display 100
#or less GO terms (GO terms annotated in very few genes
#of the species genome are removed)
#  while (nrow(stuff) > 100) {
#    stuff <- stuff[stuff$BG_Item > n_genes_with_go,]
#    n_genes_with_go <- n_genes_with_go + 1
#  }
# stuff$logFDR <- -log2(stuff$FDR)
# finite <- stuff$logFDR[is.finite(stuff$logFDR)]
# if (length(finite) > 0) {
#   stuff$logFDR[is.infinite(stuff$logFDR)] <- max(finite)+1
# } else {
#   #no finite values, all values are Inf
#   stuff$logFDR[is.infinite(stuff$logFDR)] <- 1
# }
#  stuff$size <- log2(stuff$Query_Item)
#  treemap(
#    stuff,
#    index = "GO_Description",
#    vSize = "size",
#    type = "value",
#    vColor = "E_Score",
#    title = t,
#    lowerbound.cex.labels = 0,
#    bg.labels = "#CCCCCCAA",
#    position.legend = "bottom",
#    title.legend = "Enrichment score",
#    palette = c("#0066FF", "#FFFFFF", "#FF0000"),
#    mapping=c(min(stuff$E_Score), mean(stuff$E_Score), max(stuff$E_Score))
#  )
#  # return(stuff$GO_ID) #used GO IDs to plot in treemap
#}

#addParents <- function(merged) {
#  mergedFULL <- merged
#  mergedFULL$`GO term` <- apply(merged,1,function(x, xy=xx) {
#    parent <- x[1]
#    allParents <- c(parent)
#    while(parent != "all") {
#      parent <- xx[[parent]][1]
#      if (is.null(parent)) {
#        return(NA)
#      }
#      allParents <- c(parent, allParents)
#    }
#    paste(allParents,collapse=",")
#  })
#  mergedFULL <- na.omit(mergedFULL)
#  return(mergedFULL)
#}

#getLevelForPlot <- function(level, mergedFULL, what2) {
#  level <- level + 1
#mergedFULL2 <- mergedFULL
#  for (x in 1:nrow(mergedFULL2)) {
#    s <- strsplit(mergedFULL2[x,1],",")[[1]]
#    if (length(s)>=level) {
#      mergedFULL2[x,1] <- Term(s[level])
#      if (nchar(mergedFULL2[x,1])>50) {
#        mergedFULL2[x,1] <- paste(substring(mergedFULL2[x,1], 1, 47),"...",sep="")
#      }
#    } else {
#      mergedFULL2[x,1] <- NA
#    }
#  }
#  mergedFULL2 <- na.omit(mergedFULL2)
#  #aggregating
#  if (what2 == "genenumber") {
#    mergedFULL2 <- aggregate(. ~ `GO term`, mergedFULL2, sum)
#  } else if (what2 == "enrichment") {
#    mergedFULL2 <- aggregate(. ~ `GO term`, mergedFULL2, mean)
#  }
#  mmerged <- melt(mergedFULL2, id="GO term")
#  return(mmerged)
#}

#plotBarPlot <- function(df, level, outFile) {
#  #df with gene number
#  bp1 <- df[,c(1,5,10)]
#  colnames(bp1) <- c("GO term", "Value")
#  #df with enrichment score
#  bp2 <- df[,c(1,10)]
#  colnames(bp2) <- c("GO term", "Value")
#  #add GO parents
#  r1 <- addParents(bp1) #gene number
#  r2 <- addParents(bp2) #enrichment score
#  #get Go anem for the corresponding level
#  r1 <- getLevelForPlot(level, r1, "genenumber") #gene number
#  r2 <- getLevelForPlot(level, r2, "enrichment") #enrichment score
#  r <- merge(r1, r2, by=c("GO term", "variable"))
#  colnames(r) <- c("GO term", "variable", "Gene number", "Enrichment score")
#  ggplot(data=r, aes(x=`GO term`, y=`Enrichment score`, fill=`Gene number`)) +
#    geom_bar(stat="identity") +
#    theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
#    coord_flip() +
#    scale_fill_gradientn(colours = c("steelblue", "gray", "tomato")) +
#    xlab("GO terms") + ylab("Enrichment score") +
#    labs(fill='Gene number') +
#    theme(legend.position = "bottom") +
#    theme_classic()
#  ggsave(outFile, dpi=300, height=1.5+length(unique(r$`GO term`))*0.15, width=7)
#}

##doing stuff below

#up_file <- file.info("matrix_GO_UP_test_descriptions_genes")
#down_file <- file.info("matrix_GO_DOWN_test_descriptions_genes")

#if (up_file$size > 0) {
#  GO_matrix_UP <- doAnalysis("matrix_GO_UP_test_descriptions_genes")
#  #filter
#  bp <- subset(GO_matrix_UP,GO_Category=="biological_process")
#  mf <- subset(GO_matrix_UP,GO_Category=="molecular_function")
#  cc <- subset(GO_matrix_UP,GO_Category=="cellular_component")
#  #write results to file
#  write.table(x=bp,"results_bp.txt",sep="\t",col.names=F,row.names=F,quote=F)
#  write.table(x=mf,"results_mf.txt",sep="\t",col.names=F,row.names=F,quote=F)
#  write.table(x=cc,"results_cc.txt",sep="\t",col.names=F,row.names=F,quote=F)
#  #Bar plots
#  if (nrow(bp) > 1) {
#    plotBarPlot(bp, 2, "results_bp_level2.png")
#    plotBarPlot(bp, 3, "results_bp_level3.png")
#    plotBarPlot(bp, 4, "results_bp_level4.png")
#    plotBarPlot(bp, 5, "results_bp_level5.png")
#    plotBarPlot(bp, 6, "results_bp_level6.png")
#    plotBarPlot(bp, 7, "results_bp_level7.png")
#  }
#  pdf(file="goea_up.pdf", width=16, height=9)
#  if (nrow(bp) > 1) {
#    plotTreeMap("Biological Processes", bp)
#  }
#  if (nrow(mf) > 1) {
#    plotTreeMap("Molecular Functions", mf)
#  }
#  if (nrow(cc) > 1) {
#    plotTreeMap("Cellular Components", cc)
#  }
#  dev.off()
#} else {
#  file.create("results.txt")
#}

###############################33
#library("myTAI")
#data=c("Homo sapiens", "Mus musculus")
#sapply(data, function(x) taxonomy(x, db = "ncbi", output   = "taxid"))

##package https://cran.r-project.org/web/packages/rentrez/rentrez.pdf
## see https://github.com/ropensci/rentrez/issues/141
#library(rentrez)
#taxon_search = entrez_search(db="taxonomy", term="Spirometra erinaceieuropaei")
#taxon_search$ids

# all_the_links <- entrez_link(dbfrom='gene', id=6446572, db='all')
# all_the_links$links

# #nombres de los genes
# all_the_links <- entrez_link(dbfrom='taxonomy', id=99802, db='all')
#  all_the_links$links$taxonomy_gene

#  #convertir nombres
##  https://david.ncifcrf.gov/conversion.jsp



